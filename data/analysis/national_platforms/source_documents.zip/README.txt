Complete document texts and original PDF captures; see manifest.json for source URLs, hashes, attribution, and screening status.
PDFs are deduplicated by SHA-256. Non-PDF documents are supplied as complete article text, not surrounding website scripts, forms, or navigation.
Proposal packets and evidence-only records are not adopted platforms. Check each record's screening status; unamended proposal text must not be substituted for a resolution adopted with amendments.
Original authors and publishers retain their rights.
